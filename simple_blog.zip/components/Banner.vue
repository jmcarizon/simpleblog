<template>
    <div class="_banner">
        <div class="_big_wrap">
            <div class="_carousel">
                <div class="carousel_items" :class="direction">
                    <template v-for="(item, i) in divider">
                            <div  :class="['_row-center items_container', {active: divActive == i}]" :key="i">
                                <figure v-for="(post, index) in splitedList.slice(i * itemsPerRow, (i + 1) * itemsPerRow)" :key="index" class="_col _item">
                                    <img :src="post.img" :alt="item.name">
                                    <div class="_wrapper">
                                        <div class="txt-right _banner-content _row-column-center">
                                            <div class="_col">
                                                <span class="clr-bg-black jp-font text_content" v-html="post.name"></span>
                                            </div>
                                            <div class="_col">
                                                <span class="is-block date">{{ post.date }}</span>
                                            </div>
                                        </div>
                                    </div>
                                </figure>
                            </div>
                    </template>
                </div>
                <div class="move">
                    <a href="javascript:;" :class="['prev', {disabled: divActive == 0}]" @click="move('prev')"></a>
                    <a href="javascript:;" :class="['next', {disabled: divActive == (divider.length - 1)}]" @click="move('next')"></a>
                </div>
            </div>
        </div>
    </div>
</template>

<style lang="scss" scoped>
    @import '~/assets/scss/banner.scss';
</style>

<script>
export default {
    data() {
        return {
            items: [
                {
                    name: `サンプルテキスト <br/>サンプル ルテキストサン <br/>プルテキスト`,
                    img: require('../assets/images/banner/banner1.png'),
                    date: '2019.06.19'
                },
                {  
                    name: `Royal Extra White 400gsm`,
                    img: 'https://static.singaprinting.com/v2/images/samplepack/carousel/royal_extra_white_400gsm.jpg',
                    date: '/'
                },
                {  
                    name: `Vintage Kraft 300gsm`,
                    img: 'https://static.singaprinting.com/v2/images/samplepack/carousel/vintage_kraft_300gsm.JPG',
                    date: '/'
                }
            ],
            lists: 'bc',
            itemsPerRow: 1,
            divActive: 0,
            direction: null,
        }
    },
    methods: {
        move(i) {
            this.direction = i

            if(i == 'next') {
                this.divActive = this.divActive+1
            } else if(i == 'prev') {
                this.divActive = this.divActive-1
            }
        }
    },
    computed: {
		divider() {
			return Array.from(Array(Math.ceil(this.items.length / this.itemsPerRow)).keys())
		},
		splitedList(){
            let newArr = [...this.items]
            newArr.map(function(el)  {
                setTimeout(function() {
                    el.name        = el.name,
                    el.img      = el.img,
                    el.link     = el.link
                }, 1000)
            })
			return newArr
		},
	}
}
</script>