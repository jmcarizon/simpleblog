<template>
    <main class="_main_container">
        <Banner />
    </main>
</template>

<script>
import Banner from '~/components/Banner.vue'

export default {
  components: {
    Banner,
  }
}
</script>
