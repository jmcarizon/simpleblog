<template>
    <footer class="_footer">
        <div class="_big_wrap">
            <div class="clr-bg-dark _bottom">
                <div class="_wrapper">
                    <div class="_row-column-itemcr footer-row">
                        <div class="_col-ungrow">
                            <nuxt-link class="footer-logo" to="/">
                                <img src="~/assets/images/logo-footer.png" alt="Blog Logo">
                            </nuxt-link>
                        </div>
                        <div class="_col-ungrow">
                            <div class="bottom-text">
                            <p class="jp-font">サンプルテキストサンプルテキストサンプルテキスト </p>
                            <p class="jp-font">サンプルテキストサンプルテキスト</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="clr-bg-black txt-center _copyright">
                <span class="is-block">Copyright©2007-2019 Blog Inc.</span>
            </div>
        </div>
    </footer>
</template>

<style lang="scss" scoped>
    @import '~/assets/scss/footer.scss';
</style>